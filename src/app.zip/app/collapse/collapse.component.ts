import { Component, OnInit } from '@angular/core';
import {PeriodicElement2} from "../tasks/tasks.component";

@Component({
  selector: 'app-collapse',
  templateUrl: './collapse.component.html',
  styleUrls: ['./collapse.component.css']
})
export class CollapseComponent implements OnInit {
  public isCollapsed = false;
  constructor() { }

  ngOnInit(): void {
  }


  addtask()
  {
    let PeriodicElement2:PeriodicElement2;

  }

}
