import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-basic',
  templateUrl: './alert-basic.component.html',
  styleUrls: ['./alert-basic.component.css']
})
export class AlertBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
